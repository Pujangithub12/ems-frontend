import api from "../../../api/axios";
import { User } from "../../../types";

/** Only name/email/role are collected from the inviting admin — the invitee
 * fills in phone/address/job position themselves when accepting the invite. */
export type InviteUserPayload = {
  fullName: string;
  email: string;
  role: string;
};

export type UpdateUserPayload = Partial<{
  fullName: string;
  email: string;
  password: string;
  phoneNumber: string;
  address: string;
  jobPosition: string;
  joinDate: string;
  role: string;
}>;

/** GET /api/users — every member of the current organization. */
export async function getUsers(): Promise<User[]> {
  const res = await api.get<User[]>("/api/users");
  return res.data;
}

/**
 * POST /api/users/invite — sends an organization invite for a brand-new email
 * (no account created yet), or, if the email already has an account from
 * another organization, immediately adds that existing account as a member here
 * instead. Returns the backend's message so the caller can show which one
 * happened.
 */
export async function inviteUser(payload: InviteUserPayload): Promise<{ message: string }> {
  const res = await api.post("/api/users/invite", payload);
  return res.data;
}

/** PUT /api/users/:id — partial update, shared by the full-edit form and the single-field role picker. */
export async function updateUser(id: number, payload: UpdateUserPayload): Promise<void> {
  await api.put(`/api/users/${id}`, payload);
}

/** DELETE /api/users/:id — removes a member from the organization. */
export async function deleteUser(id: number): Promise<void> {
  await api.delete(`/api/users/${id}`);
}

/** PUT /api/me/password — shared by Profile and Settings > Security. */
export async function changeMyPassword(payload: {
  currentPassword: string;
  newPassword: string;
}): Promise<void> {
  await api.put("/api/me/password", payload);
}

/**
 * PUT /api/me — the signed-in user's own contact details. Returns `any`
 * (not the organization-member `User` type above) since the caller feeds this
 * straight into AuthProvider's separately-typed session `User` shape.
 */
export async function updateMyProfile(payload: {
  phoneNumber?: string;
  address?: string;
}): Promise<any> {
  const res = await api.put("/api/me", payload);
  return res.data.user;
}

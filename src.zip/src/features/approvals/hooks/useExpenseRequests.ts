import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "../../../lib/queryKeys";
import { useOrganizationId } from "../../../hooks/useOrganizationId";
import {
  getExpenseRequests,
  createExpenseRequest,
  updateExpenseRequestStatus,
  CreateExpenseRequestPayload,
} from "../api/expenseRequests.api";

export function useExpenseRequests() {
  const wsId = useOrganizationId();
  return useQuery({
    queryKey: queryKeys.expenseRequests(wsId),
    queryFn: getExpenseRequests,
    enabled: Number.isFinite(wsId),
  });
}

export function useCreateExpenseRequest() {
  const wsId = useOrganizationId();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: CreateExpenseRequestPayload) => createExpenseRequest(payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.expenseRequests(wsId) });
    },
  });
}

export function useUpdateExpenseRequestStatus() {
  const wsId = useOrganizationId();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status }: { id: number; status: "approved" | "rejected" }) =>
      updateExpenseRequestStatus(id, status),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.expenseRequests(wsId) });
    },
  });
}

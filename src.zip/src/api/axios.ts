import axios from "axios";

const rawBase = import.meta.env.VITE_API_BASE_URL;
let API_BASE = rawBase ?? "http://localhost:3000";

// Normalize common shorthand values like ":4000" or "//host:port"
if (typeof window !== "undefined") {
  try {
    if (API_BASE.startsWith(":")) {
      API_BASE = `${window.location.protocol}//${window.location.hostname}${API_BASE}`;
      console.warn(`[api] Resolved VITE_API_BASE_URL shorthand to ${API_BASE}`);
    } else if (API_BASE.startsWith("//")) {
      API_BASE = `${window.location.protocol}${API_BASE}`;
      console.warn(`[api] Resolved VITE_API_BASE_URL to ${API_BASE}`);
    }
  } catch (e) {
    // ignore in non-browser contexts
  }
}

// Exposed so non-axios consumers (the notification socket connection) can
// point at the same backend host without re-deriving/re-normalizing it.
export const apiBaseUrl = API_BASE;

const api = axios.create({
  baseURL: API_BASE,
  headers: {
    "Content-Type": "application/json",
    // Auth is cookie-based and the cookie is SameSite=None in production
    // (required since the frontend and API are cross-site), which defeats
    // SameSite's normal CSRF protection. JSON requests are already safe —
    // "application/json" isn't a CORS-"simple" content type, so the browser
    // preflights them and the backend's origin whitelist blocks anything
    // not from this app. File uploads (multipart/form-data) ARE a simple
    // request though, so without this header they'd skip preflight
    // entirely and a malicious page could submit one using a logged-in
    // victim's cookies. Adding any non-simple header forces the same
    // preflight+origin-check for those too — see requireCsrfHeader on the
    // backend, which rejects any upload route request missing it.
    "X-Requested-With": "XMLHttpRequest",
  },
  withCredentials: true,
});

// The active organization is derived from the URL (see DashboardLayout), not
// from the shared organizationId cookie — this lets each request declare which
// organization it's scoped to synchronously, so switching organizations takes
// effect on the very next request instead of racing a cookie update.
let activeOrganizationId: number | null = null;

export function setActiveOrganizationId(id: number | null) {
  activeOrganizationId = id;
}

// Fired whenever the backend rejects a request with the
// WORKSPACE_ACCESS_FORBIDDEN code (see authMiddleware / OrganizationController)
// — e.g. an invited-user account trying to reach or create an organization other
// than the one it was invited into. Registered once by a component mounted
// near the app root (see App.tsx) so this axios module, which has no access
// to React state, can still surface a global error modal.
let onAccessForbidden: (() => void) | null = null;

export function setAccessForbiddenHandler(fn: (() => void) | null) {
  onAccessForbidden = fn;
}

api.interceptors.request.use((config) => {
  if (activeOrganizationId !== null) {
    config.headers.set("X-Workspace-Id", String(activeOrganizationId));
  }
  return config;
});

// Response interceptor to handle 401s
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Don't redirect if we're already on a login page or checking initial auth
      const isLoginPath = window.location.pathname.startsWith("/login");
      const isMePath = error.config.url?.includes("/api/me");

      if (!isLoginPath && !isMePath) {
        window.location.href = "/login";
      }
    }
    if (error.response?.data?.code === "WORKSPACE_ACCESS_FORBIDDEN") {
      onAccessForbidden?.();
    }
    return Promise.reject(error);
  },
);

// Expose debug info in development to help trace connection errors
if (import.meta.env.DEV && typeof window !== "undefined") {
  try {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    window.__API_BASE = API_BASE;
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    window.__API = api;
    console.info(`[api] axios baseURL = ${API_BASE || "(relative)"}`);
  } catch (e) {
    // ignore
  }
}

export default api;
